//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <arcore_flutter_plugin/ArcoreFlutterPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [ArcoreFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"ArcoreFlutterPlugin"]];
}

@end
